const a = 10;
import { fn } from './3';
console.log(fn());
export { a };
console.log(a+1);