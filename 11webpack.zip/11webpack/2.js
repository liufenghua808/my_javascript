import { a } from './1';
import './1.css';  //webpack只支持js文件格式，想引用其他格式文件需要进行转换
//import './1.less';
console.log(a);