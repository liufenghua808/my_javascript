export function fn() {
    return { fn }
}