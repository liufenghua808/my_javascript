import {a} from './1';
import './1.css';
import './1.less';
console.log(a+4);