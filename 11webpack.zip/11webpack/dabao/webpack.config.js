const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
//webpack的配置文件
const obj = {
    mode:'production',
    //入口文件，让webpack去分析文件
    // entry:'./2.js',
    // entry:['./2','./1'], //多入口单出口
    entry:{
        index:'./2',
        aa:'./1'
    },
    //出口文件（打包后的文件放在哪，叫什么名字）
    output:{
        // filename:'haha.js',
        filename:'[name].js',
        path:path.resolve(__dirname,'./build')
    },
    module:{
        rules:[
            {
                test:/\.css$/,
                use:['style-loader','css-loader']
            },
            {
                test: /\.less$/,
                use: [{
                    loader: "style-loader"
                }, {
                    loader: "css-loader"
                }, {
                    loader: "less-loader", options: {
                        strictMath: true,
                        noIeCompat: true
                    }
                }]
            }
        ]
    },
    plugins:[
        new HtmlWebpackPlugin({
            title:'首页',
            filename: 'index.html',//文件名称
            template: './index.html'//基于哪个模板
        })
    ]
}

module.exports = obj;