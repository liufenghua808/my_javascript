//webpack的配置文件
const path = require('path');
const HTML = require('html-webpack-plugin');
const webpack = require('webpack');

//热加载不需要再刷新页面了
if (module.hot) {
    module.hot.accept(); //不加参数默认接受所有格式的文件
}
const obj = {
    mode: 'development',  //模式：开发环境
    entry: {
        index: './2',
    },

    //开发环境不需要设置出口
    // output: {
    //     filename: 'index.js',
    //     path: path.resolve(__dirname, './build')
    // },


    //loader
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [
                    {
                        loader: 'style-loader'   //将样式添加到DOM中
                    },
                    {
                        loader: 'css-loader'    //将css文件打包
                    }
                ]
            }
        ]
    },
    //开发环境服务
    devServer: {
        port: 3000,
        open: true,
        hot: true,//只需要 hot:true即实现热更新
        compress:true,
        clientLogLevel:'warning'
        
    },


    plugins: [
        new HTML({
            title: '首页',
            filename: 'index.html',
            template: './index.html'
        }),
        new webpack.HotModuleReplacementPlugin(),  
    ]


}

module.exports = obj;