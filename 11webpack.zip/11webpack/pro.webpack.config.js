//webpack的配置文件

const path = require('path');

//抽离html和js的
const HtmlWebpackPlugin = require('html-webpack-plugin');

//抽离CSS
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

//webpack的配置文件
const obj = {
    mode: 'production',

    //入口文件，让webpack去分析文件
    // entry: './2.js',   字符串格式
    //entry:['./2','./1'],//多入口文件   数组格式
    //对象格式
    entry: {
        index: './2',
        aa: './1'
    },

    /*出口文件(打包后的文件放在哪里，叫什么名字)
    * filename:'handle.js',//打包的文件名称
    * path:path.resolve(__dirname,'/bulid') //把handle文件放到当前文件夹下
    * filename: '[name].[hash:8].js',  name就表示entry的key  index  aa
    */
    output: {
        // filename: 'bundle.js',
        filename: '[name].js',
        //filename: '[name].[hash:4].js',
        path: path.resolve(__dirname, './build')
    },


    //loader
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [
                    {
                        loader: 'style-loader'   //将样式添加到DOM中
                    },
                    {
                        loader: 'css-loader'    //将css文件打包
                    }
                ]
            },
            {
                test: /\.less$/,
                use: [
                    {
                        loader: 'style-loader'
                    },
                    {
                        loader: 'css-loader'
                    },
                    {
                        loader: 'less-loader', options: {
                            strictMath: true,
                            noIeCompat: true

                        }
                    }
                ]
            }
        ]
    },

    plugins: [
        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: './index.html'  //基于哪个文件模板

        }),
        new MiniCssExtractPlugin({
            filename:'[name].css'
        })

    ]


}

module.exports = obj;