//开发环境webpack配置文件设置

const path = require('path');

const HTML = require('html-webpack-plugin');

const webpack = require('webpack');

// if (module.hot) {
//     module.hot.accept();
// }
const obj = {
    mode: 'development',
    entry: {
        index: './2',
    },
    module: {
        rules: [
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            }
        ]
    },

    devServer: {
        port: 3001,
        hot: true,
        open: true,
        compress: true,
        clientLogLevel: 'warning',

        //服务器代理，可跨域
        proxy: {
            '/api': {
                target: 'http://www.yijianbaoshui.com/acc/queryAll.do',
                changeOrigin: true,
                pathRewrite: { "^/api": "" } // 将/api重写为""空字符串
            }
        }

    },
    plugins: [
        new HTML({
            title: 'demo',
            filename: 'index.html',
            template: './index.html'
        }),
        //new webpack.HotModuleReplacementPlugin()
    ],

}



module.exports = obj;