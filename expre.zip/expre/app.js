const express = require("express");
const app = express();
let sql = [
    {
        name: 'xiaoming',
        pass: 123456
    },
    {
        name: 'xiaoming1',
        pass: 123456
    },
    {
        name: 'xiaoming2',
        pass: 123456
    }
]
//走文件
app.use(express.static('www'));

//失焦接口
app.get('/user', (request, response) => {
    let obj = request.body;
    console.log(obj);
    let o = sql.find(item => item.name === obj.user);
    if (o) {
        response.json({ code: 1, msg: '用户名已占用' });
    } else {
        if (obj.user && obj.pass) {
            sql.push({
                name: obj.user,
                pass: obj.pass
            })
            response.json({ code: 0, msg: '成功' });
        } else {
            response.json({ code: 1, msg: '输入有误' });
        }
    }
})

//注册接口
app.get('/get', (request, response) => {
    let obj = request.query;
    console.log(obj);
    let o = sql.find(item => item.name === obj.user);
    if (o) {
        response.json({ code: 1, msg: '用户名已占用' });
    } else {
        if (obj.user && obj.pass) {
            sql.push({
                name: obj.user,
                pass: obj.pass
            })
            response.json({ code: 0, msg: '成功' });
        } else {
            response.json({ code: 1, msg: '输入有误' });
        }
    }

})


app.listen(80);