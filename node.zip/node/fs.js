const fs = require('fs');

//读文件
fs.readFile('./1.txt', (error, data) => {
    if (error) {
        console.log('失败');
    } else {
        console.log(data.toString())
    }
});


//写入文件
/**
 * fs.writeFile('文件写入路径','文件内容',回调函数)
 */
fs.writeFile('./www/404.html','404',(error)=>{
    if(error){
        console.log('写入失败');
    }else{
        console.log('写入成功');
    }
})

//删除文件
/**
 * fs.writeFile('文件写入路径','文件内容',回调函数)
 */
fs.unlink('./www/2.txt',(error)=>{
    if(error){
        console.log('删除失败');
    }else{
        console.log('成功');
    }
})



