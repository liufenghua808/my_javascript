const http = require('http');
const fs = require('fs');
const querystring = require('querystring');
//创建服务器
/* 
    request:发送请求  客户端请求
    response:响应   发送给客户端
*/
let sql=['xiaoming','xiaohong','libai']
http.createServer((request, response) => {
    let url = request.url;

    if (url !== '/favicon.ico') {
        //找文件
        if (url.includes('.html')) {
            try {
                let d = fs.readFileSync('./www' + url);
                response.write(d.toString());
            } catch (error) {
                let er = fs.readFileSync('./www/404.html');
                response.write(er.toString());
            }
            //发送结束
            response.end();
        } else {
            //找接口
            if (url === '/post') {
                let str = '';
                request.on('data', (d) => {
                    str += d;
                })

                request.on('end', () => {
                    let obj = querystring.parse(str);
                    response.setHeader('Content-Type', 'text/html;charset=utf-8');
                    if (sql.includes(obj.user)) {
                        response.write(JSON.stringify({ code: 1, msg: '用户名被占用' }))
                    } else {
                        response.write(JSON.stringify({ code: 0, msg: 'success' }))
                    }
                    response.end();

                })
            }

        }
    }

}).listen(80);