const http = require('http');
//创建服务器
/* 
    request:发送请求  客户端请求
    response:响应   发送给客户端
*/
let sql = [
    {
        user: 'xiaoming',
        password: 123
    },
    {
        user: 'xiaohong',
        password: 456
    },
    {
        user: 'libai',
        password: 123456
    }
]

const app = http.createServer((request, response) => {
    let url = request.url;//接收到客户端发送的请求带的参数 key=value&key1=value1
    let obj = {}; //字符串转成对象{key=value,key1=value1}
    if (url !== '/favicon.ico') {
        url.split('?')[1].split('&').forEach(item => {
            let ary = item.split('=');
            obj[ary[0]] = ary[1];
        });
         console.log(obj);
        //查找传入的参数在数据库（数组）中是否有
        let o = sql.find((e) => e.user === obj.user);
        response.setHeader('Content-Type', 'text/html;charset=utf-8');

        //发送给客户端
        //如果数据库（数组）中有相同数据，提示占用
        if (o) {
            response.write(obj.cb + "({'code':1,'msg':'用户名已被占用'})");
        } else {
            response.write(obj.cb + "({'code':0,'msg':'请求成功'})");
        }
     


        //发送结束
        response.end();
    }

})

app.listen(80);