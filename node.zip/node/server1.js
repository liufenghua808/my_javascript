const http = require('http');
const fs = require('fs');

const app = http.createServer((request, response) => {
    let ary = ['\.html', '\.txt', '\.js', '\.css', '\.png'];
    let url = request.url;
    if (url !== '/favicon.ico') {
        let re = new RegExp('(' + ary.join('|') + ')');
        console.log(re);
        // console.log('访问的是文件');
        if (re.test(url)) {
            //读取本地文件
            fs.readFile('www' + url, (error, data) => {
                if (error) {
                    response.write('404');
                } else {
                    response.setHeader('Content-Type', 'text/html;charset=utf-8');
                    response.write(data);
                }

                response.end();
            })
        }
    }

})

app.listen(80);