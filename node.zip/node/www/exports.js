function fn(){
    return 10;
}

module.exports = {
    fn
};