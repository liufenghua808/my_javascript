const obj = require('./exports');
console.log(obj);

console.log(obj.fn());//10